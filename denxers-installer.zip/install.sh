#!/bin/bash
echo 'Menjalankan setup Denxers...'
