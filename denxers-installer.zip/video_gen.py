# Gabungkan skrip + suara + background
